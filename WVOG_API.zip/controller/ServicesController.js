const mongoose = require("mongoose");
const Service = mongoose.model("service");
const BookService = mongoose.model("bookService");

const createService = async (req, res) => {
  try {
    const { title, content } = req?.body;
    if (!title) {
      return res.status(400).send({
        status: 0,
        message: "please enter title",
      });
    } else if (!content) {
      return res.status(400).send({
        status: 0,
        message: "please enter content",
      });
    }
    const serviceImage = req?.files?.serviceImage;
    const serviceImagePath = serviceImage
      ? serviceImage[0]?.path?.replace(/\\/g, "/")
      : null;
    const service = await Service.create({
      title,
      content,
      serviceImage: serviceImagePath,
    });
    return res.status(200).send({
      status: 1,
      message: "service created succesfully",
      data: service,
    });
  } catch (err) {
    console.error("Error", err.message);
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};

const editService = async (req, res) => {
  try {
    const { title, content, id } = req?.body;
    if (!id) {
      return res.status(400).send({
        status: 0,
        message: "please enter ID",
      });
    } else if (!mongoose.isValidObjectId(id)) {
      return res.status(400).send({
        status: 0,
        message: "please enter a valid ID",
      });
    } else if (!title) {
      return res.status(400).send({
        status: 0,
        message: "please enter title",
      });
    } else if (!content) {
      return res.status(400).send({
        status: 0,
        message: "please enter content",
      });
    }
    const service = await Service.findById(id);
    if (!service) {
      return res.status(400).send({
        status: 0,
        message: "service not found",
      });
    }
    const serviceImage = req?.files?.serviceImage;
    const serviceImagePath = serviceImage
      ? serviceImage[0]?.path?.replace(/\\/g, "/")
      : null;
    // console.log(serviceImagePath)
    const updateService = await Service.findByIdAndUpdate(
      id,
      {
        title,
        content,
        serviceImage: serviceImagePath,
      },
      { new: true }
    );
    return res.status(200).send({
      status: 1,
      message: "updated service successfully!",
      data: updateService,
    });
  } catch (err) {
    console.error("Error", err.message);
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};

const deleteService = async (req, res) => {
  try {
    const id = req?.query?.id;
    if (!id) {
      return res.status(400).send({
        status: 0,
        message: "please enter ID",
      });
    } else if (!mongoose.isValidObjectId(id)) {
      return res.status(400).send({
        status: 0,
        message: "please enter a valid ID",
      });
    }
    const service = await Service.findById(id);
    if (!service) {
      return res.status(400).send({
        status: 0,
        message: "service not found",
      });
    }
    await BookService.deleteMany({ serviceId: id });
    await Service.findByIdAndDelete(id);
    return res.status(200).send({
      status: 1,
      message: "service deleted successfully",
    });
  } catch (err) {
    console.error("Error", err.message);
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};

const getAllServices = async (req, res) => {
  try {
    const services = await Service.find({}).sort({ createdAt: -1 });
    if (services?.length < 1) {
      return res.status(200).send({
        status: 1,
        message: "no services found!",
      });
    } else {
      return res.status(200).send({
        status: 1,
        message: "fetched all services",
        services,
      });
    }
  } catch (err) {
    console.error("Error", err.message);
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};

const getServiceDetails = async (req, res) => {
  try {
    const id = req?.query?.id;
    if (!id) {
      return res.status(400).send({
        status: 0,
        message: "please enter ID",
      });
    } else if (!mongoose.isValidObjectId(id)) {
      return res.status(400).send({
        status: 0,
        message: "please enter a valid ID",
      });
    }
    const service = await Service.findById(id);
    if (!service) {
      return res.status(400).send({
        status: 0,
        message: "service not found",
      });
    } else {
      return res.status(200).send({
        status: 0,
        message: "service fetched successfully",
        service,
      });
    }
  } catch (err) {
    console.error("Error", err.message);
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};

//book service
const bookService = async (req, res) => {
  try {
    const userId = req?.user?._id;
    const id = req?.query?.id;
    if (!id) {
      return res.status(400).send({
        status: 0,
        message: "please enter ID",
      });
    } else if (!mongoose.isValidObjectId(id)) {
      return res.status(400).send({
        status: 0,
        message: "please enter a valid ID",
      });
    }
    const service = await Service.findById(id);
    if (!service) {
      return res.status(400).send({
        status: 0,
        message: "service not found",
      });
    }
    const book_service = await BookService.findOne({
      userId: userId,
      serviceId: id,
    });
    if (book_service) {
      return res.status(200).send({
        status: 1,
        message: "user has already booked service",
      });
      // const booked_service_id = book_service?._id;
      // const isBooked = book_service?.isBooked;
      // const updateook_service = await BookService.findByIdAndUpdate(
      //   booked_service_id,
      //   {
      //     isBooked: !isBooked,
      //   },
      //   { new: true }
      // );
      // if (isBooked) {
      //   return res.status(200).send({
      //     status: 1,
      //     message: "service has been successfully booked",
      //     data: updateook_service,
      //   });
      // } else {
      //   return res.status(200).send({
      //     status: 1,
      //     message: "service booking has been canceled",
      //     data: updateook_service,
      //   });
      // }
    } else {
      const bookingService = new BookService({
        userId: userId,
        serviceId: id,
        isBooked: 1,
      });
      const data = await bookingService.save();
      return res.status(200).send({
        status: 1,
        message: "service has been successfully booked",
        data,
      });
    }
  } catch (err) {
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};
const unBookService = async (req, res) => {
  try {
    const userId = req?.user?._id;
    const id = req?.query?.id;
    if (!id) {
      return res.status(400).send({
        status: 0,
        message: "please enter ID",
      });
    } else if (!mongoose.isValidObjectId(id)) {
      return res.status(400).send({
        status: 0,
        message: "please enter a valid ID",
      });
    }
    const service = await Service.findById(id);
    if (!service) {
      return res.status(400).send({
        status: 0,
        message: "service not found",
      });
    }
    const bookedService = await BookService.findOne({
      userId: userId,
      serviceId: id,
    });
    if (bookedService) {
      const updatedService = await BookService.findByIdAndUpdate(
        id,
        {
          isBooked: 0,
        },
        { new: true }
      );
      return res.status(200).send({
        status: 1,
        message: "service has been successfully unbooked",
        data: updatedService,
      });
    } else {
      return res.status(200).send({
        status: 1,
        message: "user has not booked service",
      });
    }
  } catch (err) {
    return res.status(500).send({
      status: 0,
      message: "Something went wrong",
    });
  }
};

module.exports = {
  createService,
  editService,
  deleteService,
  getAllServices,
  getServiceDetails,
  bookService,
  unBookService
};
